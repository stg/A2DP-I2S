#!/usr/bin/env python3
"""Install a selectable A2DP-I2S board from an official Arduino-ESP32 3.x core."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import shutil
import sys
from typing import Optional


MIN_VERSION = (3, 0, 7)
MAX_VERSION = (4, 0, 0)
VALIDATED_VERSIONS = {(3, 3, 11)}
BOARD_FQBN = "a2dp-i2s:esp32:a2dp-i2s"


def version_tuple(value: str):
    match = re.match(r"^(\d+)\.(\d+)\.(\d+)(?:$|[-+])", value)
    return tuple(map(int, match.groups())) if match else None


def default_arduino_data() -> Path:
    system = platform.system()
    if system == "Windows":
        return Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData/Local")) / "Arduino15"
    if system == "Darwin":
        return Path.home() / "Library/Arduino15"
    return Path.home() / ".arduino15"


def default_sketchbook() -> Path:
    return Path.home() / "Documents/Arduino" if platform.system() in {"Windows", "Darwin"} else Path.home() / "Arduino"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_manifest(release_root: Path) -> dict:
    manifest_path = release_root / "manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    for relative, expected in manifest["files"].items():
        actual = sha256(release_root / relative)
        if actual.lower() != expected.lower():
            raise RuntimeError(f"Payload checksum mismatch: {relative}")
    return manifest


def installed_platforms(data_dir: Path):
    root = data_dir / "packages/esp32/hardware/esp32"
    result = []
    if root.is_dir():
        for entry in root.iterdir():
            version = version_tuple(entry.name)
            if version and entry.is_dir():
                result.append((version, entry.name, entry))
    return sorted(result)


def select_platform(data_dir: Path, requested: Optional[str]):
    platforms = installed_platforms(data_dir)
    if requested:
        platforms = [entry for entry in platforms if entry[1] == requested]
        if not platforms:
            raise RuntimeError(f"Arduino-ESP32 {requested} is not installed below {data_dir}")

    compatible = [entry for entry in platforms if MIN_VERSION <= entry[0] < MAX_VERSION]
    if not compatible:
        found = ", ".join(entry[1] for entry in platforms) or "none"
        raise RuntimeError(
            "A2DP-I2S requires Arduino-ESP32 >= 3.0.7 and < 4.0.0. "
            f"Installed versions: {found}"
        )
    return compatible[-1]


def sdk_tool_path(data_dir: Path, platform_dir: Path, platform_version: str) -> Path:
    installed = json.loads((platform_dir / "installed.json").read_text(encoding="utf-8"))
    packages = installed.get("packages", [])
    selected = None
    for package_entry in packages:
        if package_entry.get("name") != "esp32":
            continue
        for candidate in package_entry.get("platforms", []):
            if candidate.get("version") == platform_version:
                selected = candidate
                break
    if selected is None:
        raise RuntimeError(f"Cannot find the {platform_version} dependency manifest")

    for dependency in selected.get("toolsDependencies", []):
        if dependency.get("name") in {"esp32-libs", "esp32-arduino-libs"}:
            path = (
                data_dir
                / "packages"
                / dependency.get("packager", "esp32")
                / "tools"
                / dependency["name"]
                / dependency["version"]
            )
            if path.is_dir():
                return path
            raise RuntimeError(f"The matching ESP32 SDK library package is missing: {path}")
    raise RuntimeError("The selected Arduino-ESP32 installation has no SDK library dependency")


def link_or_copy(source: str, destination: str) -> str:
    try:
        os.link(source, destination)
        return destination
    except OSError:
        return shutil.copy2(source, destination)


def replace_file(source: Path, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists() or destination.is_symlink():
        destination.unlink()
    shutil.copy2(source, destination)


def patch_platform(platform_dir: Path, release_version: str, base_version) -> None:
    path = platform_dir / "platform.txt"
    lines = path.read_text(encoding="utf-8").splitlines()
    output = []
    for line in lines:
        if line.startswith("name="):
            line = "name=A2DP-I2S ESP32"
        elif line.startswith("version="):
            line = f"version={release_version}"
        elif line.startswith("tools.esp32-arduino-libs.path.windows="):
            line = r"tools.esp32-arduino-libs.path.windows={runtime.platform.path}\a2dp-i2s-sdk"
        elif line.startswith("tools.esp32-arduino-libs.path="):
            line = "tools.esp32-arduino-libs.path={runtime.platform.path}/a2dp-i2s-sdk"
        elif line.startswith("build.extra_flags=") and "A2DP_I2S_CUSTOM_CORE" not in line:
            compatibility = ""
            if base_version < (3, 1, 0):
                compatibility = "-DCONFIG_BTDM_CTRL_BR_EDR_MAX_SYNC_CONN_EFF=0 "
            line = line.replace("=", f"=-DA2DP_I2S_CUSTOM_CORE=1 {compatibility}", 1)
        output.append(line)
    path.write_text("\n".join(output) + "\n", encoding="utf-8")


def patch_boards(platform_dir: Path) -> None:
    path = platform_dir / "boards.txt"
    lines = path.read_text(encoding="utf-8").splitlines()
    menus = [line for line in lines if line.startswith("menu.")]
    start = next((index for index, line in enumerate(lines) if line.startswith("esp32.name=")), None)
    if start is None:
        raise RuntimeError("Cannot find the generic ESP32 board definition")
    end = len(lines)
    for index in range(start + 1, len(lines)):
        if re.match(r"^[A-Za-z0-9_]+\.name=", lines[index]):
            end = index
            break
    board = [line.replace("esp32.", "a2dp-i2s.", 1) if line.startswith("esp32.") else line for line in lines[start:end]]
    board[0] = "a2dp-i2s.name=A2DP-I2S ESP32"
    path.write_text("\n".join(menus + [""] + board) + "\n", encoding="utf-8")


def install(args: argparse.Namespace) -> None:
    release_root = Path(__file__).resolve().parent
    manifest = load_manifest(release_root)
    data_dir = args.arduino_data.expanduser().resolve()
    sketchbook = args.sketchbook.expanduser().resolve()
    version, version_text, stock_platform = select_platform(data_dir, args.esp32_version)

    if version not in VALIDATED_VERSIONS:
        print(f"WARNING: Arduino-ESP32 {version_text} is within the supported 3.x range but is not hardware-validated.")
        print("         Installation will continue; test Bluetooth operation before relying on it.")

    stock_sdk = sdk_tool_path(data_dir, stock_platform, version_text)
    target = sketchbook / "hardware/a2dp-i2s/esp32"
    marker = target / ".a2dp-i2s-install.json"
    if target.exists():
        if not marker.is_file():
            raise RuntimeError(f"Refusing to replace an unmanaged directory: {target}")
        shutil.rmtree(target)

    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(stock_platform, target)
    custom_sdk = target / "a2dp-i2s-sdk"
    shutil.copytree(stock_sdk, custom_sdk, copy_function=link_or_copy)

    sdk_root = custom_sdk if (custom_sdk / "lib/libbt.a").is_file() else custom_sdk / "esp32"
    if not (sdk_root / "lib/libbt.a").is_file():
        raise RuntimeError("Cannot locate the ESP32 libbt.a in the installed SDK package")

    payload = release_root / "payload"
    replace_file(payload / "libbt.a", sdk_root / "lib/libbt.a")
    replace_file(
        payload / "a2dp_i2s_a2dp.h",
        sdk_root / "include/bt/host/bluedroid/api/include/api/a2dp_i2s_a2dp.h",
    )
    replace_file(payload / "sdkconfig", sdk_root / "sdkconfig")
    config_headers = list(sdk_root.glob("*_qspi/include/sdkconfig.h"))
    if not config_headers:
        raise RuntimeError("Cannot locate the ESP32 SDK configuration headers")
    for config_header in config_headers:
        replace_file(payload / "sdkconfig.h", config_header)

    patch_platform(target, manifest["version"], version)
    patch_boards(target)
    marker.write_text(
        json.dumps(
            {
                "a2dp_i2s_version": manifest["version"],
                "arduino_esp32_version": version_text,
                "arduino_data": str(data_dir),
                "stock_sdk": str(stock_sdk),
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )

    print(f"Installed A2DP-I2S {manifest['version']} from Arduino-ESP32 {version_text}")
    print(f"Board path: {target}")
    print(f"Board FQBN: {BOARD_FQBN}")
    print("Restart Arduino IDE, then select A2DP-I2S ESP32.")


def uninstall(args: argparse.Namespace) -> None:
    target = args.sketchbook.expanduser().resolve() / "hardware/a2dp-i2s/esp32"
    marker = target / ".a2dp-i2s-install.json"
    if not target.exists():
        print("A2DP-I2S is not installed in this sketchbook.")
        return
    if not marker.is_file():
        raise RuntimeError(f"Refusing to remove an unmanaged directory: {target}")
    shutil.rmtree(target)
    print(f"Removed A2DP-I2S board platform: {target}")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--arduino-data", type=Path, default=default_arduino_data())
    parser.add_argument("--sketchbook", type=Path, default=default_sketchbook())
    parser.add_argument("--esp32-version", help="use a particular installed Arduino-ESP32 version")
    parser.add_argument("--uninstall", action="store_true")
    args = parser.parse_args()
    try:
        uninstall(args) if args.uninstall else install(args)
        return 0
    except (OSError, RuntimeError, ValueError, KeyError, json.JSONDecodeError) as error:
        print(f"ERROR: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
