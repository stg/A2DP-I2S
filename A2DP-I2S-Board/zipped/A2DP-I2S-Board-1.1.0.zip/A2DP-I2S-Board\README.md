# A2DP-I2S Arduino board

Install the official **Espressif ESP32** board package in Arduino IDE first. A2DP-I2S accepts Arduino-ESP32 versions from 3.0.7 through the 3.x line; unvalidated 3.x versions produce a warning, while older versions and 4.x are rejected.

Extract this archive and run:

```text
python install.py
```

Restart Arduino IDE and select **Tools > Board > A2DP-I2S ESP32 > A2DP-I2S ESP32**.

The installer creates a separate board platform from the existing official installation. It does not modify or replace the official ESP32 core. Use `python install.py --help` for non-default Arduino locations or `python install.py --uninstall` to remove it.

The installed A2DP-I2S board remains a snapshot of the selected Arduino-ESP32 version. Rerun `install.py` after upgrading or changing the official ESP32 board package.
