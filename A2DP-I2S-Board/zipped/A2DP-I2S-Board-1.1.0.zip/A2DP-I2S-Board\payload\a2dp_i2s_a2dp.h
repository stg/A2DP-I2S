/* SPDX-License-Identifier: Apache-2.0 */
#pragma once

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include "esp_err.h"

#ifdef __cplusplus
extern "C" {
#endif

enum {
    RB_A2DP_RATE_16000 = 1u << 0,
    RB_A2DP_RATE_32000 = 1u << 1,
    RB_A2DP_RATE_44100 = 1u << 2,
    RB_A2DP_RATE_48000 = 1u << 3,
};

typedef enum {
    RB_A2DP_EVENT_READY,
    RB_A2DP_EVENT_CONNECTED,
    RB_A2DP_EVENT_DISCONNECTED,
    RB_A2DP_EVENT_STREAM_STARTED,
    RB_A2DP_EVENT_STREAM_SUSPENDED,
    RB_A2DP_EVENT_CODEC_CONFIGURED,
    RB_A2DP_EVENT_AVRCP_CONNECTED,
    RB_A2DP_EVENT_AVRCP_DISCONNECTED,
    RB_A2DP_EVENT_PROTOCOL,
} rb_a2dp_event_t;

typedef void (*rb_a2dp_pcm_cb_t)(const int16_t *samples, size_t byte_count,
                                 uint64_t packet_arrival_us,
                                 uint32_t source_sample_index, void *context);
typedef void (*rb_a2dp_event_cb_t)(rb_a2dp_event_t event, uint32_t value, void *context);
typedef void (*rb_avrc_metadata_cb_t)(uint8_t attribute_mask, const uint8_t *text,
                                      size_t text_length, void *context);

typedef struct {
    const char *device_name;
    uint8_t sample_rate_mask;
    /* Optional local preference. The source still selects any advertised
       masked rate; the negotiated rate is reported in CODEC_CONFIGURED. */
    uint16_t preferred_sample_rate;
    rb_a2dp_pcm_cb_t pcm_callback;
    rb_a2dp_event_cb_t event_callback;
    /* Bit zero is title, bit one artist, through bit six playing time. */
    uint8_t metadata_attribute_mask;
    /* Allow a new BR/EDR source to replace the currently connected source.
       The one-host-ACL implementation performs the handover while the incoming
       HCI connection request is pending, so the requester need not retry. */
    bool preemption;
    rb_avrc_metadata_cb_t metadata_callback;
    void *callback_context;
} rb_a2dp_config_t;

/* Select before esp_bluedroid_init(). Audio-only mode avoids initializing
   RFCOMM and BTA control blocks used solely by the reboot-only OTA route. */
void rb_bluedroid_set_audio_only(bool enabled);
bool rb_bluedroid_audio_only(void);
esp_err_t rb_a2dp_start(const rb_a2dp_config_t *config);
esp_err_t rb_a2dp_disconnect(void);
bool rb_a2dp_connected(void);
uint16_t rb_a2dp_sample_rate(void);
/* Cap the peer's L2CAP automatic-flush request for the incoming AVDTP media
   channel. Zero accepts the peer's requested timeout unchanged. Set before a
   source opens the media channel. */
void rb_a2dp_set_media_flush_timeout(uint16_t timeout_ms);
/* Set the local AVDTP media-channel MTU advertised during the next open.
   Zero restores the backend default (1008 bytes). */
void rb_a2dp_set_media_mtu(uint16_t mtu);
/* operation_id uses the AVRCP pass-through operation IDs (play=0x44, etc.). */
esp_err_t rb_avrc_passthrough(uint8_t operation_id, bool pressed);
bool rb_avrc_connected(void);

/* Internal HCI seams. They are public only because the reduced A2DP backend
   and Bluedroid HCI dispatcher are separate translation units. */
bool a2dp_i2s_preempt_connection_request(const uint8_t address[6],
                                         const uint8_t device_class[3]);
void a2dp_i2s_acl_connection_complete(uint8_t status, uint16_t handle,
                                      const uint8_t address[6]);
void a2dp_i2s_preempt_disconnection_complete(uint16_t handle);
void a2dp_i2s_scan_command_complete(uint8_t status);

uint16_t a2dp_i2s_media_flush_timeout(void);

#ifdef __cplusplus
}
#endif
